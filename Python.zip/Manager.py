import sys
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from firebase_admin import auth



#Show all Users from DB
def show_all_users():
    ref = db.reference('User')
    print("Please wait...\nThe Users:")
    dict = ref.get()
    if(dict != None):
        list=[]
        for uid in dict.keys():
            list.append(uid)
        index = 0
        for user in dict.values():
            num=(index+1)
            print "User number: " + str(num) + "\nUID: " + list[index]
            for key, val in user.items():
                print key +": "+ val
            print
            index += 1
    else:
        print "No Users in the DB!"


#Delete User by input UID
def delete_user_by_input():
    show_all_users()
    print "Choose an UID from the list to delete"
    ref = db.reference('User')
    dict = ref.get()
    if dict != None :
        while True:
            choose = (raw_input("Please enter UID to remove: "))
            for uid in dict.keys():
                if uid == choose:
                    auth.delete_user(choose)
                    print "User has been deleted"
                    ref.child(uid).delete()
                    return
            print "Problem with the uid please try again"
    else:
        print "No Users in the DB!"

#Add User to DB
def add_new_user():
    UserName = (raw_input("Please enter Your UserName: "))
    FirstName = (raw_input("Please enter Your FirstName: "))
    LastName = (raw_input("Please enter Your LastName: "))
    Password = (raw_input("Please enter Your password(at least Six letters): "))
    City = (raw_input("Please enter Your City: "))
    Street = (raw_input("Please enter Your Street: "))
    Email = (raw_input("Please enter Your Email: "))
    userAuth = auth.create_user(email=Email, password=Password)
    ref = db.reference('User').child(userAuth.uid)
    ref.set({
        'UserName': UserName,
        'FirstName': FirstName,
        'LastName': LastName,
        'Password': Password,
        'City': City,
        'Street': Street,
        'Email': Email,

    })
    print "User added successfully!!!"


    return


#Menu
def menu():
    print("Menu:\nPress 1 to Show all Users\nPress 2 to Delete User by Input\nPress 3 to Add new user\nPress 4 to Exit")
    while True:
        try:
            choose = int(raw_input("Please enter your choice: "))
            if choose != 1 and choose != 2 and choose !=3 and choose !=4:
                raise ValueError
        except ValueError:
            print("Sorry, please enter again number between 1 to 4")
            continue
        else:
            break
    if choose == 1:  # user choose to Show all Users
        show_all_users()
    elif choose == 2:
        delete_user_by_input()
    elif choose == 3:
        add_new_user()
    else:
        print("Bye Bye")
        sys.exit()



cred = credentials.Certificate("C:\Users\Adiram Shemesh\AndroidStudioProjects\ShoppingLists\shoppinglists-7f8a8-firebase-adminsdk-vlxcw-f008001307.json")
firebase_admin.initialize_app(cred, {'databaseURL': 'https://shoppinglists-7f8a8.firebaseio.com/'})
while True:
    menu()